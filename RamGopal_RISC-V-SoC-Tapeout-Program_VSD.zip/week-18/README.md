# Week 18 notes

- Tasks planned:
- Tasks completed:
- Blockers:
- Artifacts:

# Week 05 notes

- Tasks planned:
- Tasks completed:
- Blockers:
- Artifacts:

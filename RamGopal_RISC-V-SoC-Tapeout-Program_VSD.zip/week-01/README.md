# Week 01 notes

- Tasks planned:
- Tasks completed:
- Blockers:
- Artifacts:

# Week 08 notes

- Tasks planned:
- Tasks completed:
- Blockers:
- Artifacts:

# Week 02 notes

- Tasks planned:
- Tasks completed:
- Blockers:
- Artifacts:

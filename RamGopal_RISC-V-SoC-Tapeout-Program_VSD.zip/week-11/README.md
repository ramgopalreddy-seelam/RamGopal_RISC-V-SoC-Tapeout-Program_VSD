# Week 11 notes

- Tasks planned:
- Tasks completed:
- Blockers:
- Artifacts:

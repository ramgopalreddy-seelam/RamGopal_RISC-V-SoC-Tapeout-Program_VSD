# Week 06 notes

- Tasks planned:
- Tasks completed:
- Blockers:
- Artifacts:

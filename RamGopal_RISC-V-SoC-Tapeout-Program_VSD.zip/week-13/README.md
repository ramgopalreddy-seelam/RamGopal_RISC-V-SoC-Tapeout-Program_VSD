# Week 13 notes

- Tasks planned:
- Tasks completed:
- Blockers:
- Artifacts:

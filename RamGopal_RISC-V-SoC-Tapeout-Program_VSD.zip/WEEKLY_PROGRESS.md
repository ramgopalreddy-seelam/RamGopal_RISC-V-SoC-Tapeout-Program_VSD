# Weekly Progress Tracker

This file is a living tracker. For each week, list tasks planned, tasks done, blocking issues, and artifacts produced.

## Legend
- ✅ Done
- 🔲 In progress
- ⛔ Blocked
- 📎 Artifact attached

---

### Week 01 — Kickoff
**Planned**
- Project setup (repo, tool access)
- Understand RTL baseline and SoC block diagram
- Get PDK and Synopsys tool access
- Basic hello-world program for the core

**Done**
- ✅

**Blockers**
- None

**Artifacts**
- `work/rtl/` initial skeleton

---

### Week 02 — RTL integration
**Planned**
- Integrate CPU core + bus + memory map
- Create testbench and run basic simulations

**Done**
- ✅

**Blockers**
- None

**Artifacts**
- `work/rtl/`, `work/tb/`

---

<!-- Duplicate the template for weeks 03..20 -->

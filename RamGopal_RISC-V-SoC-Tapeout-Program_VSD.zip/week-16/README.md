# Week 16 notes

- Tasks planned:
- Tasks completed:
- Blockers:
- Artifacts:

# Contributing

- Keep a weekly log entry.
- Use descriptive commit messages.
- Tag artifacts with week number: `weekXX_artifact.ext`.

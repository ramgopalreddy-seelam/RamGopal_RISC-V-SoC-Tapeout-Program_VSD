# Week 10 notes

- Tasks planned:
- Tasks completed:
- Blockers:
- Artifacts:

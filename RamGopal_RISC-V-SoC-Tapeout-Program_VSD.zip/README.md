# RamGopal_RISC-V-SoC-Tapeout-Program_VSD

This repository documents my (Ram Gopal) progress through the **RISC‑V Reference SoC Tapeout Program (VSD)**.
It is modeled after other participants' trackers and includes a weekly progress tracker, notes, RTL and verification folders, and delivery artifacts.

## Structure

- `README.md` — Project overview and quick links (this file).
- `WEEKLY_PROGRESS.md` — Week-by-week entries and checklist.
- `work/` — source code: RTL, testbenches, scripts.
- `docs/` — notes, reports, PDK links, floorplans, schematics.
- `images/` — screenshots and photos.
- `gds/` — GDSII and layout-related deliverables.
- `hardware/` — post-silicon test plans, bring-up scripts.
- `scripts/` — build, simulation, flow automation scripts.
- `LICENSE` — project license (add your preferred license).
- `.gitignore` — common ignores for EDA projects.

## Quick start

1. Clone this repo locally.
2. Add your RTL under `work/rtl/`.
3. Keep weekly updates inside `WEEKLY_PROGRESS.md` or as separate `week-XX/` notes.
4. Use branches for major milestones (e.g., `week-05-synthesis`, `apr`, `tapeout`).


# Week 12 notes

- Tasks planned:
- Tasks completed:
- Blockers:
- Artifacts:

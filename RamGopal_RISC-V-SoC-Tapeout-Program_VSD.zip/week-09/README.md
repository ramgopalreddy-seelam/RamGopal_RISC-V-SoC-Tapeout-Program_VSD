# Week 09 notes

- Tasks planned:
- Tasks completed:
- Blockers:
- Artifacts:

# Week 15 notes

- Tasks planned:
- Tasks completed:
- Blockers:
- Artifacts:
